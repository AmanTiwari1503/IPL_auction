module.exports = {
	encry:'##Lets%Jwt%EveryThing##',
	clever:'%%Blocking#Clever#Users%%',
	referal: '%%lIFE#Remains#crazy%%',
	passbook: '##Lets%Jwt%EveryThing##'
}